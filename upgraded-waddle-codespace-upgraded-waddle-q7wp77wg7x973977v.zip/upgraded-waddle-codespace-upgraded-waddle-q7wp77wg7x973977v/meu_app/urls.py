from django.urls import path
from . import views


urlpatterns = [
    path('', views.lista_equipamentos, name='lista_equipamentos'),

    path(
        'cadastro/',
        views.cadastrar_equipamento,
        name='cadastrar_equipamento'
    ),

    path(
        'equipamento/<int:id>/',
        views.detalhes_equipamento,
        name='detalhes_equipamento'
    ),
]