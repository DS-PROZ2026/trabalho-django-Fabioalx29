from django.shortcuts import render, redirect, get_object_or_404
from .models import Equipamento
from .forms import EquipamentoForm


# Listagem / Dashboard
def lista_equipamentos(request):
    equipamentos = Equipamento.objects.all()

    return render(request, 'meu_app/lista.html', {
        'equipamentos': equipamentos
    })


# Cadastro
def cadastrar_equipamento(request):

    if request.method == 'POST':
        form = EquipamentoForm(request.POST)

        if form.is_valid():
            form.save()
            return redirect('lista_equipamentos')

    else:
        form = EquipamentoForm()

    return render(request, 'meu_app/cadastro.html', {
        'form': form
    })


# Detalhes
def detalhes_equipamento(request, id):
    equipamento = get_object_or_404(Equipamento, id=id)

    return render(request, 'meu_app/detalhes.html', {
        'equipamento': equipamento
    })